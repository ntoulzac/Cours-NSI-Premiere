from IPython.display import display, HTML

def table_de_verite(nb_var, expression):
    if nb_var == 2:
        booleen = [(0, 0), (0, 1), (1, 0), (1, 1)]
        for k in range(4):
            a = booleen[k][0]
            b = booleen[k][1]
            booleen[k] = eval(expression)
        html = f"""
            <table>
            <thead>
            <tr>
            <th align="center"><code>a</code></th>
            <th align="center"><code>b</code></th>
            <th align="center"><code>{expression}</code></th>
            </tr>
            </thead>
            <tbody>
            <tr>
            <td align="center">0</td>
            <td align="center">0</td>
            <td align="center">{int(booleen[0])}</td>
            </tr>
            <tr>
            <td align="center">0</td>
            <td align="center">1</td>
            <td align="center">{int(booleen[1])}</td>
            </tr>
            <tr>
            <td align="center">1</td>
            <td align="center">0</td>
            <td align="center">{int(booleen[2])}</td>
            </tr>
            <tr>
            <td align="center">1</td>
            <td align="center">1</td>
            <td align="center">{int(booleen[3])}</td>
            </tr>
            </tbody>
            </table>
        """
        display(HTML(html))
    
    elif nb_var == 3:
        booleen = [(0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1), (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1)]
        for k in range(8):
            a = booleen[k][0]
            b = booleen[k][1]
            c = booleen[k][2]
            booleen[k] = eval(expression)
        html = f"""
            <table>
            <thead>
            <tr>
            <th align="center"><code>a</code></th>
            <th align="center"><code>b</code></th>
            <th align="center"><code>c</code></th>
            <th align="center"><code>{expression}</code></th>
            </tr>
            </thead>
            <tbody>
            <tr>
            <td align="center">0</td>
            <td align="center">0</td>
            <td align="center">0</td>
            <td align="center">{int(booleen[0])}</td>
            </tr>
            <tr>
            <td align="center">0</td>
            <td align="center">0</td>
            <td align="center">1</td>
            <td align="center">{int(booleen[1])}</td>
            </tr>
            <tr>
            <td align="center">0</td>
            <td align="center">1</td>
            <td align="center">0</td>
            <td align="center">{int(booleen[2])}</td>
            </tr>
            <tr>
            <td align="center">0</td>
            <td align="center">1</td>
            <td align="center">1</td>
            <td align="center">{int(booleen[3])}</td>
            </tr>
            <tr>
            <td align="center">1</td>
            <td align="center">0</td>
            <td align="center">0</td>
            <td align="center">{int(booleen[4])}</td>
            </tr>
            <tr>
            <td align="center">1</td>
            <td align="center">0</td>
            <td align="center">1</td>
            <td align="center">{int(booleen[5])}</td>
            </tr>
            <tr>
            <td align="center">1</td>
            <td align="center">1</td>
            <td align="center">0</td>
            <td align="center">{int(booleen[6])}</td>
            </tr>
            <tr>
            <td align="center">1</td>
            <td align="center">1</td>
            <td align="center">1</td>
            <td align="center">{int(booleen[7])}</td>
            </tr>
            </tbody>
            </table>
            """
        display(HTML(html))