import struct

NORMAL = "\033[0;0m"
NOIR_GRAS = "\033[1;30m"
ROUGE_GRAS = "\033[1;31m"
BLEU_GRAS = "\033[1;34m"
VERT_GRAS = "\033[1;32m"

def _bin32(x):
    return [bin(c).replace("0b", "").rjust(8, "0") for c in struct.pack("!f", x)]

def float_bin32(x):
    """
    Renvoie la représentation IEEE 754 d'un flottant sur 32 bits.
    - Entrée : x (flottant)
    - Sortie : (chaîne de caractères)
    """
    bits = "".join(_bin32(x))
    return VERT_GRAS + bits[0] + ROUGE_GRAS + bits[1:9] + BLEU_GRAS + bits[9:] + NORMAL

def _bin64(x):
    return [bin(c).replace("0b", "").rjust(8, "0") for c in struct.pack("!d", x)]

def float_bin64(x):
    """
    Renvoie la représentation IEEE 754 d'un flottant sur 64 bits.
    - Entrée : x (flottant)
    - Sortie : (chaîne de caractères)
    """
    bits = "".join(_bin64(x))
    return VERT_GRAS + bits[0] + ROUGE_GRAS + bits[1:12] + BLEU_GRAS + bits[12:] + NORMAL

def _octet_vers_entier(octet):
    entier = 0
    for k in range(len(octet)):
        entier = entier + int(octet[k]) * 2**(len(octet)-1-k)
    return entier

def _binaire_vers_mantisse(bits):
    mantisse = 1
    for k in range(len(bits)):
         mantisse = mantisse + int(bits[k]) * 2**(-1-k)
    return mantisse

def _bitification(bits):
    bits = bits.replace("\033[0;0m", "").replace("\033[1;30m", "").replace("\033[1;31m", "").replace("\033[1;32m", "").replace("\033[1;34m", "")
    return bits

def bin32_float(bits):
    """
    Renvoie le flottant associé à une représentation sur 32 bits donnée.
    - Entrée : bits (chaîne de caractères composée de 32 bits)
    - Sortie : flottant (flottant)
    """
    bits = _bitification(bits)
    if len(bits) != 32 or len(bits.replace("0", "").replace("1", "")) != 0:
        raise ValueError("l'argument ne contient pas 32 bits")
    elif bits == "0" * 32:
        return 0.0
    elif bits == "0" + "1" * 8 + "0" * 23:
        return float("inf")
    elif bits == "1" + "1" * 8 + "0" * 23:
        return float("-inf")
    elif bits[:9] == "011111111" or bits[:9] == "111111111":
        return float("NaN")
    signe = (-1) ** int(bits[0])
    exposant = _octet_vers_entier(bits[1:9]) - 127
    mantisse = _binaire_vers_mantisse(bits[9:])
    flottant = signe * mantisse * 2 ** exposant
    return flottant

def bin64_float(bits):
    """
    Renvoie le flottant associé à une représentation sur 64 bits donnée.
    - Entrée : bits (chaîne de caractères composée de 64 bits)
    - Sortie : flottant (flottant)
    """
    bits = _bitification(bits)
    if len(bits) != 64 or len(bits.replace("0", "").replace("1", "")) != 0:
        raise ValueError("l'argument ne contient pas 64 bits")
    elif bits == "0" * 64:
        return 0.0
    elif bits == "0" + "1" * 11 + "0" * 52:
        return float("inf")
    elif bits == "1" + "1" * 11 + "0" * 52:
        return float("-inf")
    elif bits[:12] == "011111111111" or bits[:12] == "111111111111":
        return float("NaN")
    signe = (-1) ** int(bits[0])
    exposant = _octet_vers_entier(bits[1:12]) - 1023
    mantisse = _binaire_vers_mantisse(bits[12:])
    flottant = signe * mantisse * 2 ** exposant
    return flottant