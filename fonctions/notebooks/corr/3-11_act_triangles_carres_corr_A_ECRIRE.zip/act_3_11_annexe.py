import turtle

def ouvrir_fenetre():
    fenetre = turtle.Screen()
    turtle.TurtleScreen._RUNNING = True
    turtle.colormode(255)
    turtle.speed('fastest')
    turtle.hideturtle()
    return fenetre

def fermer(fenetre):
    fenetre.exitonclick()