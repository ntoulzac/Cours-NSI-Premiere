def a(b, c):
    d = c
    for e in range(c+1, len(b)):
        if b[e] < b[d]:
            d = e
    return d

def tri_selection(f):
    for g in range(len(f)-1):
        h = a(f, g)
        f[g], f[h] = f[h], f[g]