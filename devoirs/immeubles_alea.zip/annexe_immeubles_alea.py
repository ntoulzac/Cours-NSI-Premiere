from IPython.display import display, HTML

def demarrer_svg(largeur, hauteur):
    """
    Débute la création d'un code SVG en spécifiant les dimensions du dessin.
    - Entrées : largeur, hauteur (entiers)
    - Sortie : svg (chaîne de caractères correspondant à du code SVG)
    """
    return f"""<svg xmlns="http://www.w3.org/2000/svg" width="{largeur}" height="{hauteur}">
                <polygon stroke="black" stroke-width="3" points="0 0 0 {hauteur} {largeur} {hauteur} {largeur} 0" fill="#f0f0f0"/>
                """

def terminer_svg(svg):
    """
    Termine la création d'un code SVG.
    - Entrée : svg (chaîne de caractères correspondant à du code SVG)
    - Sortie : svg (chaîne de caractères correspondant à du code SVG)
    """
    return svg + "</svg>"

def ajouter_rectangle(svg, coin, largeur, hauteur, couleur):
    """
    Ajoute un rectangle dans une image au format SVG.
    - Entrées : svg (chaîne de caractères correspondant à du code SVG),
                coin (couple de coordonnées du coin supérieur gauche du rectangle),
                largeur, hauteur (entiers, dimensions du rectangle)
                couleur (chaîne au format "#rrvvbb" pour un rectangle colorée, ou None pour un rectangle vide)
    """
    x, y = coin
    x2, y2 = x + largeur, y
    x3, y3 = x + largeur, y + hauteur
    x4, y4 = x, y + hauteur
    rect = f"""<polygon stroke="black" stroke-width="1.5" points="{x} {y} {x2} {y2} {x3} {y3} {x4} {y4}" {'fill="'+couleur+'"' if couleur is not None else ""}/>"""
    return svg + rect

def ajouter_triangle(svg, coin1, coin2, coin3, couleur):
    """
    Ajoute un triangle dans une image au format SVG.
    - Entrées : svg (chaîne de caractères correspondant à du code SVG),
                coin1, coin2, coin3 (couples de coordonnées des sommets du triangle),
                couleur (chaîne au format "#rrvvbb" pour un rectangle colorée, ou None pour un rectangle vide)
    """
    x, y = coin1
    x2, y2 = coin2
    x3, y3 = coin3
    tri = f"""<polygon stroke="black" stroke-width="1.5" points="{x} {y} {x2} {y2} {x3} {y3}" {'fill="'+couleur+'"' if couleur is not None else ""}/>"""
    return svg + tri

def afficher_svg(svg):
    """
    Affiche dans le notebook une image SVG à partir de son code.
    - Entrée : svg (chaîne de caractères correspondant à du code SVG)
    Effet : affichage à l'écran
    """
    display(HTML(svg))